CREATE DATABASE IF NOT EXISTS portfolio_one
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE portfolio_one;

CREATE TABLE  users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') NOT NULL DEFAULT 'user',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE  registration_records (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NULL,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(190) NOT NULL,
    role ENUM('user', 'admin') NOT NULL DEFAULT 'user',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_registration_email (email),
    INDEX idx_registration_user_id (user_id)
);

CREATE TABLE login_records (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NULL,
    email VARCHAR(190) NOT NULL,
    role ENUM('user', 'admin') NOT NULL DEFAULT 'user',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_login_email (email),
    INDEX idx_login_user_id (user_id)
);

CREATE TABLE  service_requests (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NULL,
    client_name VARCHAR(150) NOT NULL,
    email VARCHAR(190) NOT NULL,
    phone VARCHAR(50) NULL,
    service_type VARCHAR(120) NOT NULL,
    budget_range VARCHAR(80) NULL,
    preferred_contact VARCHAR(40) NOT NULL DEFAULT 'Email',
    project_details TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE  feedback_messages (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_id INT UNSIGNED NULL,
    recipient_user_id INT UNSIGNED NULL,
    recipient_email VARCHAR(190) NOT NULL,
    admin_user_id INT UNSIGNED NOT NULL,
    admin_name VARCHAR(120) NOT NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_feedback_recipient_user_id (recipient_user_id),
    INDEX idx_feedback_recipient_email (recipient_email),
    INDEX idx_feedback_request_id (request_id)
);
